words = [
    "APPLE",
    "MANGO",
    "BUTTERFLY",
    "BEAUTIFUL",
    "DAVID",
    "PETER",
    "GRAPES",
    "POTATO",
    "TOMATO",
    "DELHI",
    "MUMBAI",
    "NAGPUR",
    "PUNJAB",
    "THANKYOU"
]  # you have to excess more words, if you wants.