import random
import hangman_stages
import words_file

# Word list initializing
word_list = words_file.words
chosen_word = random.choice(word_list).upper()
lives = len(hangman_stages.stages) - 1

# Initialize game variables
display = ['_' for _ in chosen_word]
guessed_letters = set()
is_game_over = False

print("Welcome to Hangman!!")
print(" ".join(display))

# Main game loop
while not is_game_over:
    guessed_letter = input("Guess a letter: ").upper()

    # Check for repeated guesses
    if guessed_letter in guessed_letters:
        print(f"You've already guessed '{guessed_letter}'. Try again!")
        continue

    guessed_letters.add(guessed_letter)

    # Check guessed letter
    if guessed_letter in chosen_word:
        for position in range(len(chosen_word)):
            if chosen_word[position] == guessed_letter:
                display[position] = guessed_letter
        print("Correct guess!")
    else:
        lives -= 1
        print(f"Wrong guess! You lose a life. Lives remaining: {lives}")

    # Display the current state
    print(" ".join(display))
    print(hangman_stages.stages[lives])

    # Check game-over conditions
    if '_' not in display:
        is_game_over = True
        print("Congratulations, you win!")
    elif lives == 0:
        is_game_over = True
        print(f"You lose! The word was '{chosen_word}'.")
